using Microsoft.EntityFrameworkCore;
using share_clothes_api.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services
builder.Services.AddControllers();
builder.Services.AddDbContext<ApiDbContext>(options =>
    options.UseSqlite(builder.Configuration.GetConnectionString("DefaultConnection")));
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// ✅ Seed Data 
/*using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<ApiDbContext>();

    if (!db.FundraisingCards.Any())
    {
        db.FundraisingCards.AddRange(
            new FundraisingCard { Title = "Palestina", Description = "Donera livsnödvändiga kläder", ImageUrl = "palestine.jpg" },
            new FundraisingCard { Title = "Sudan", Description = "Hjälp familjer på flykt", ImageUrl = "sudan.jpg" },
            new FundraisingCard { Title = "Ukraina", Description = "Stöd utsatta familjer", ImageUrl = "ukraine.jpg" }
        );

        db.SaveChanges();
    }
}*/


// Middleware
app.UseSwagger();
app.UseSwaggerUI();
app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();

app.Run();