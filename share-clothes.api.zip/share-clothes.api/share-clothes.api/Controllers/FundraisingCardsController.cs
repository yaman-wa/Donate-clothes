using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using share_clothes_api.Models;

namespace share_clothes_api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FundraisingCardsController : ControllerBase
    {
        private readonly ApiDbContext _context;

        public FundraisingCardsController(ApiDbContext context)
        {
            _context = context;
        }

        // GET: api/FundraisingCards
        [HttpGet]
        public async Task<IActionResult> GetCards()
        {
            var cards = await _context.FundraisingCards.ToListAsync();
            return Ok(cards);
        }

        // GET: api/FundraisingCards/5
        [HttpGet("{id}")]
        public async Task<IActionResult> GetCard(int id)
        {
            var card = await _context.FundraisingCards.FindAsync(id);
            if (card == null)
                return NotFound();

            return Ok(card);
        }

        // POST: api/FundraisingCards
        [HttpPost]
        public async Task<IActionResult> CreateCard(FundraisingCard card)
        {
            _context.FundraisingCards.Add(card);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetCard), new { id = card.Id }, card);
        }

        // PUT: api/FundraisingCards/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCard(int id, FundraisingCard card)
        {
            if (id != card.Id)
                return BadRequest();

            _context.Entry(card).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // DELETE: api/FundraisingCards/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCard(int id)
        {
            var card = await _context.FundraisingCards.FindAsync(id);
            if (card == null)
                return NotFound();

            _context.FundraisingCards.Remove(card);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
