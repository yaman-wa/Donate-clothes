using Microsoft.EntityFrameworkCore;

namespace share_clothes_api.Models
{
    public class ApiDbContext : DbContext
    {
        public ApiDbContext(DbContextOptions<ApiDbContext> options) : base(options) {}

        public DbSet<FundraisingCard> FundraisingCards { get; set; }
    }
}