﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace share_clothes.api.Migrations
{
    /// <inheritdoc />
    public partial class AddCardDetails : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ClothesCount",
                table: "FundraisingCards",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "ProgressPercentage",
                table: "FundraisingCards",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "SupportersCount",
                table: "FundraisingCards",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ClothesCount",
                table: "FundraisingCards");

            migrationBuilder.DropColumn(
                name: "ProgressPercentage",
                table: "FundraisingCards");

            migrationBuilder.DropColumn(
                name: "SupportersCount",
                table: "FundraisingCards");
        }
    }
}
