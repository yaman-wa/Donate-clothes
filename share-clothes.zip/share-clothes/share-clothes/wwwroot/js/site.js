﻿document.addEventListener('DOMContentLoaded', function () {

    // Redirect to login page
    var signInButton = document.querySelector('.sign-in');
    if (signInButton) {
        signInButton.addEventListener('click', function () {
            window.location.href = '/Account/Login';
        });
    }

    // Redirect to register page
    var registerLink = document.querySelector('.register-link');
    if (registerLink) {
        registerLink.addEventListener('click', function () {
            window.location.href = '/Account/Register';
        });
    }

    // General form validation handler
    var forms = document.querySelectorAll('form.validate');
    forms.forEach(function(form) {
        form.addEventListener('submit', function (e) {
            var isValid = true;
            var inputs = form.querySelectorAll('input[required]');

            inputs.forEach(function(input) {
                var errorSpan = input.nextElementSibling;
                if (errorSpan && errorSpan.tagName.toLowerCase() === 'span') {
                    errorSpan.textContent = '';
                }

                if (input.value.trim() === '') {
                    if (errorSpan) {
                        errorSpan.textContent = 'Fältet får inte vara tomt';
                    }
                    isValid = false;
                }

                if (input.type === 'email' && !input.value.includes('@')) {
                    if (errorSpan) {
                        errorSpan.textContent = 'Ogiltig e-postadress';
                    }
                    isValid = false;
                }

                if (input.name === 'Password' && input.value.length < 6) {
                    if (errorSpan) {
                        errorSpan.textContent = 'Lösenordet måste vara minst 6 tecken';
                    }
                    isValid = false;
                }
            });

            if (!isValid) {
                e.preventDefault();
            }
        });
    });

    console.log("Welcome to the Share Clothes platform!");
});
document.addEventListener('DOMContentLoaded', function () {
    const toastEl = document.getElementById('myToast');
    if (toastEl) {
        setTimeout(() => {
            toastEl.classList.remove('show');
            toastEl.classList.add('fade');
        }, 3000); 
    }
});
