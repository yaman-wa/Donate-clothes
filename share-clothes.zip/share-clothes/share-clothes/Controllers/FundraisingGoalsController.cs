﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using share_clothes_api.Models;
using share_clothes.Models;

namespace share_clothes.Controllers
{
    public class FundraisingGoalsController : Controller
    {
        private readonly HttpClient _httpClient;

        public FundraisingGoalsController(IHttpClientFactory httpClientFactory)
        {
            _httpClient = httpClientFactory.CreateClient();
        }

        public async Task<IActionResult> Index()
        {
            var response = await _httpClient.GetAsync("http://localhost:5140/api/FundraisingCards");
            if (!response.IsSuccessStatusCode)
            {
                return View(new List<FundraisingCard>());
            }

            var jsonData = await response.Content.ReadAsStringAsync();
            var cards = JsonConvert.DeserializeObject<List<FundraisingCard>>(jsonData);

            return View(cards);
        }

        public IActionResult Details()
        {
            return View();
        }
    }
}



