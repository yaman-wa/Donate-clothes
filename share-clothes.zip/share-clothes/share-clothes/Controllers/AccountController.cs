﻿using Microsoft.AspNetCore.Mvc;
using share_clothes.Data;
using share_clothes.Models;

namespace share_clothes.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserDbContext _context;

        // Inject DbContext عبر Constructor
        public AccountController(UserDbContext context)
        {
            _context = context;
        }

        // View login page
        public IActionResult Login()
        {
            return View();
        }

        // Login (POST)
        [HttpPost]
        public IActionResult Login(string email, string password)
        {
            var user = _context.Users.FirstOrDefault(u => u.Email == email && u.Password == password);

            if (user != null)
            {
                // Store user data in the session
                HttpContext.Session.SetInt32("UserId", user.Id);
                HttpContext.Session.SetString("UserName", user.Name);


                return RedirectToAction("Index", "Home");
            }
            else
            {
                TempData["Error"] = "Fel e-post eller lösenord.";
                return View();
            }
        }

        // View registration page
        public IActionResult Register()
        {
            return View();
        }

        //New User Registration (POST)
        [HttpPost]
        public IActionResult Register(string name, string email, string password)
        {
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                TempData["Error"] = "Alla fält måste fyllas i.";
                return View();
            }

            //Check if the email has been used before
            if (_context.Users.Any(u => u.Email == email))
            {
                TempData["Error"] = "E-posten finns redan!";
                return View();
            }

            //Add user to Db
            var user = new User
            {
                Name = name,
                Email = email,
                Password = password,
            };

            _context.Users.Add(user);
            _context.SaveChanges(); //The most important step to save data
            
            TempData["Success"] = "Ditt konto har skapats! Nu kan du logga in.";

            return RedirectToAction("Login");
        }

        //Sign out
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            TempData["Success"] = "Du har loggats ut.";
            return RedirectToAction("Login");
        }
    }
}
