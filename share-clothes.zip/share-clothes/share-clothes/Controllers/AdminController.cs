using Microsoft.AspNetCore.Mvc;
using share_clothes.Data;
using share_clothes.Models;

namespace share_clothes.Controllers
{
    public class AdminController : Controller
    {
        private readonly UserDbContext _context;

        public AdminController(UserDbContext context)
        {
            _context = context;
        }

        //  Dashboard - Displays all users within a table.
        public IActionResult Dashboard()
        {
            if (HttpContext.Session.GetInt32("UserId") == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var users = _context.Users.ToList();
            return View(users);
        }

        // Delete user from table
        [HttpPost]
        public IActionResult Delete(int id)
        {
            var user = _context.Users.FirstOrDefault(u => u.Id == id);

            if (user != null)
            {
                _context.Users.Remove(user);
                _context.SaveChanges();
                TempData["Success"] = "Användare raderad!";
            }

            return RedirectToAction("Dashboard");
        }

        // View user edit page
        public IActionResult Edit(int id)
        {
            var user = _context.Users.FirstOrDefault(u => u.Id == id);
            if (user == null)
            {
                return RedirectToAction("Dashboard");
            }

            return View(user); 
        }

        // Save changes after modifying data
        [HttpPost]
        public IActionResult Edit(User updatedUser)
        {
            var user = _context.Users.FirstOrDefault(u => u.Id == updatedUser.Id);

            if (user != null)
            {
                user.Name = updatedUser.Name;
                user.Email = updatedUser.Email;
                _context.SaveChanges();
                TempData["Success"] = "Användare uppdaterad!";
            }

            return RedirectToAction("Dashboard");
        }

        // Display the Add New User page
        public IActionResult Create()
        {
            return View();
        }

        //  Save the new user in the database
        [HttpPost]
        public IActionResult Create(User newUser)
        {
            if (ModelState.IsValid)
            {
                _context.Users.Add(newUser);
                _context.SaveChanges();
                TempData["Success"] = "Användare tillagd!";
                return RedirectToAction("Dashboard");
            }

            return View(newUser); // If there are errors in the validation, return to the same page.
        }
    }
}
