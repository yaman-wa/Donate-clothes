using Microsoft.EntityFrameworkCore;
using share_clothes.Models;
using share_clothes.Models; 

namespace share_clothes.Data 
{
    public class UserDbContext : DbContext
    {
        public UserDbContext(DbContextOptions<UserDbContext> options)
            : base(options)
        {
        }

        
        public DbSet<User> Users { get; set; }
    }
}