namespace share_clothes_api.Models //api 
{
    public class FundraisingCard
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string ImageUrl { get; set; }
        public int ClothesCount { get; set; }
        public int SupportersCount { get; set; }
        public int ProgressPercentage { get; set; }
    }
}